using Linq;

class Category
{
    public int cid { get; set; }
    public string name { get; set; }
}

class Program
{
    static List<Category> food = new()
    {
        new Category  { cid = 1, name = "Beverages" },
        new Category  { cid = 2, name = "Condiments" },
        new Category  { cid = 3, name = "Confections" },

    };

    var ii = new Category
    {
        cid = 4,
        name = "test"
    }

    var delete = from Category
                 where Category.cid == 4
                 select Category;

    foreach (var Category in delete)
        {
            db.Category.delete(Category);
        }
    try
        {
        db.submitChange();
        }
    catch (Exception e)
        {
        Console.WriteLine(e);
        throw;
        }

var update = from Category 
             where Category.cid = 3
             select Category
            ); ;

    foreach (var Category in update)
    {
    Category.name = "test2";
    }
    try
        {
        db.SubmitChanges();
        }
    catch (Exception e)
        {
           Console.WriteLine(e);
        }
    var yu = from Category 
             where Category.cid == 1
             select Category.name;
};